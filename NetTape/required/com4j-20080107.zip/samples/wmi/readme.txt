Sample that uses Windows Management Instrumentation to access Windows system information.
See http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnanchor/html/anch_wmi.asp
for more details.
